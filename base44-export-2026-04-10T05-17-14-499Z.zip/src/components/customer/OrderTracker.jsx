const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useState } from 'react';
import { ArrowLeft, Clock, ChefHat, CheckCircle2, Star } from 'lucide-react';

import { formatPrice } from '../../lib/formatPrice';

const STEPS = [
  { status: 'novo', label: 'Recebido', icon: Clock, color: 'text-blue-500', bg: 'bg-blue-50' },
  { status: 'em_preparo', label: 'Preparando', icon: ChefHat, color: 'text-amber-500', bg: 'bg-amber-50' },
  { status: 'pronto', label: 'Pronto!', icon: CheckCircle2, color: 'text-green-500', bg: 'bg-green-50' },
];

const STATUS_INDEX = { novo: 0, em_preparo: 1, pronto: 2, finalizado: 3 };

export default function OrderTracker({ orderId, onBack }) {
  const [order, setOrder] = useState(null);
  const [orderItems, setOrderItems] = useState([]);
  const [showFeedback, setShowFeedback] = useState(false);
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [feedbackSent, setFeedbackSent] = useState(false);

  useEffect(() => {
    const load = async () => {
      const o = await db.entities.Order.filter({ id: orderId });
      if (o[0]) setOrder(o[0]);
      const oi = await db.entities.OrderItem.filter({ order_id: orderId });
      setOrderItems(oi);
    };
    load();
    const interval = setInterval(load, 5000);
    return () => clearInterval(interval);
  }, [orderId]);

  useEffect(() => {
    if (order?.status === 'pronto' && !feedbackSent) {
      setTimeout(() => setShowFeedback(true), 2000);
    }
    if (order?.status === 'finalizado') {
      localStorage.removeItem('active_order_id');
    }
  }, [order?.status]);

  const submitFeedback = async () => {
    await db.entities.Feedback.create({
      order_id: orderId,
      customer_name: order?.customer_name,
      rating,
      comment,
    });
    setFeedbackSent(true);
    setShowFeedback(false);
  };

  if (!order) {
    return (
      <div className="fixed inset-0 bg-white z-50 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-amber-200 border-t-amber-500 rounded-full animate-spin" />
      </div>
    );
  }

  const currentStep = STATUS_INDEX[order.status] ?? 0;

  if (showFeedback) {
    return (
      <div className="fixed inset-0 bg-white z-50 flex flex-col items-center justify-center px-6 text-center">
        <h2 className="text-xl font-bold text-gray-900 mb-2">Seu pedido está pronto! 🎉</h2>
        <p className="text-gray-500 mb-6">Como foi sua experiência?</p>
        <div className="flex gap-2 mb-4">
          {[1, 2, 3, 4, 5].map(s => (
            <button key={s} onClick={() => setRating(s)}>
              <Star className={`w-8 h-8 ${s <= rating ? 'fill-amber-400 text-amber-400' : 'text-gray-300'}`} />
            </button>
          ))}
        </div>
        <textarea
          value={comment}
          onChange={e => setComment(e.target.value)}
          placeholder="Deixe um comentário (opcional)"
          className="w-full border rounded-xl p-3 text-sm resize-none h-20 focus:outline-none focus:ring-2 focus:ring-amber-400 mb-4"
        />
        <button onClick={submitFeedback} disabled={!rating} className="w-full bg-amber-500 text-white py-3 rounded-xl font-semibold disabled:opacity-50 mb-2">
          Enviar Avaliação
        </button>
        <button onClick={() => setShowFeedback(false)} className="text-sm text-gray-400">
          Pular
        </button>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-white z-50 flex flex-col">
      <div className="flex items-center gap-3 p-4 border-b">
        <button onClick={onBack}><ArrowLeft className="w-5 h-5 text-gray-600" /></button>
        <h2 className="font-bold text-lg">Acompanhar Pedido</h2>
      </div>

      <div className="flex-1 overflow-auto p-4">
        <p className="text-sm text-gray-500 mb-4">Olá, <strong>{order.customer_name}</strong>! Acompanhe seu pedido:</p>

        <div className="flex justify-between mb-6">
          {STEPS.map((step, i) => {
            const Icon = step.icon;
            const active = i <= currentStep;
            return (
              <div key={step.status} className="flex flex-col items-center gap-1 flex-1">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center ${active ? step.bg : 'bg-gray-100'}`}>
                  <Icon className={`w-6 h-6 ${active ? step.color : 'text-gray-300'}`} />
                </div>
                <span className={`text-xs font-medium ${active ? 'text-gray-800' : 'text-gray-400'}`}>{step.label}</span>
                {i < STEPS.length - 1 && (
                  <div className="absolute" />
                )}
              </div>
            );
          })}
        </div>

        {order.status === 'pronto' && (
          <div className="bg-green-50 border border-green-200 rounded-2xl p-4 text-center mb-4">
            <p className="text-green-700 font-bold text-lg">🎉 Seu pedido está pronto!</p>
            <p className="text-green-600 text-sm">Retire no balcão</p>
          </div>
        )}

        <div className="bg-gray-50 rounded-2xl p-4">
          <p className="font-semibold text-sm text-gray-700 mb-3">Itens do pedido</p>
          {orderItems.map(item => (
            <div key={item.id} className="flex justify-between text-sm text-gray-600 mb-1">
              <span>{item.quantity}x {item.product_name}</span>
              <span>{formatPrice(item.unit_price * item.quantity)}</span>
            </div>
          ))}
          <div className="flex justify-between font-bold mt-2 pt-2 border-t">
            <span>Total</span>
            <span className="text-amber-600">{formatPrice(order.total)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}