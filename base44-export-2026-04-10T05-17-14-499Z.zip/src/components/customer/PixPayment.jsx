import { useState, useEffect, useRef } from 'react';
import { Copy, CheckCheck, Loader2 } from 'lucide-react';
import { supabase } from '../../lib/supabaseClient';

export default function PixPayment({ total, onDone }) {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState('idle'); // idle | loading | success | error
  const [qrBase64, setQrBase64] = useState('');
  const [qrCode, setQrCode] = useState('');
  const [copied, setCopied] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const channelRef = useRef(null);

  useEffect(() => {
    return () => {
      if (channelRef.current) {
        supabase.removeChannel(channelRef.current);
      }
    };
  }, []);

  const startRealtime = (paymentId) => {
    const channel = supabase
      .channel(`payment-${paymentId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'pagamentos',
          filter: `id=eq.${paymentId}`,
        },
        (payload) => {
          if (payload.new?.status === 'approved') {
            supabase.removeChannel(channel);
            onDone();
          }
        }
      )
      .subscribe();

    channelRef.current = channel;
  };

  const generate = async () => {
    if (!email.trim()) return;
    setStatus('loading');
    setErrorMsg('');
    const res = await fetch('https://gkzyjshufbfdhmfojoos.supabase.co/functions/v1/super-task', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ valor: total, email }),
    });
    if (!res.ok) {
      setStatus('error');
      setErrorMsg('Falha ao gerar o PIX. Tente novamente.');
      return;
    }
    const data = await res.json();
    setQrBase64(data.qr_base64);
    setQrCode(data.qr_code);
    setStatus('success');
    if (data.id || data.payment_id) {
      startRealtime(data.id || data.payment_id);
    }
  };

  const copy = () => {
    navigator.clipboard.writeText(qrCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-col items-center text-center gap-4 py-4">
      <p className="text-sm text-gray-500">
        Total: <span className="font-bold text-amber-600">R$ {total.toFixed(2).replace('.', ',')}</span>
      </p>

      {status === 'idle' && (
        <div className="w-full space-y-3">
          <div className="text-left">
            <label className="text-sm font-medium text-gray-700">Seu e-mail</label>
            <input
              value={email}
              onChange={e => setEmail(e.target.value)}
              type="email"
              placeholder="seu@email.com"
              className="w-full mt-1 border rounded-xl p-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-green-400"
            />
          </div>
          <button
            onClick={generate}
            disabled={!email.trim()}
            className="w-full bg-green-500 text-white py-3 rounded-xl font-semibold disabled:opacity-40"
          >
            Gerar QR Code PIX
          </button>
        </div>
      )}

      {status === 'loading' && (
        <div className="flex flex-col items-center gap-2 py-6">
          <Loader2 className="w-8 h-8 text-green-500 animate-spin" />
          <p className="text-sm text-gray-500">Gerando pagamento...</p>
        </div>
      )}

      {status === 'error' && (
        <div className="w-full space-y-3">
          <p className="text-red-500 text-sm">{errorMsg}</p>
          <button onClick={() => setStatus('idle')} className="w-full bg-green-500 text-white py-3 rounded-xl font-semibold">
            Tentar novamente
          </button>
        </div>
      )}

      {status === 'success' && (
        <div className="w-full space-y-3">
          <p className="text-green-600 font-medium text-sm">✅ PIX gerado! Escaneie o QR Code abaixo:</p>
          {qrBase64 && (
            <img
              src={`data:image/png;base64,${qrBase64}`}
              alt="QR Code PIX"
              className="w-52 h-52 mx-auto rounded-xl border"
            />
          )}
          {qrCode && (
            <div className="bg-gray-50 rounded-xl p-3 text-left">
              <p className="text-xs text-gray-500 mb-1">PIX Copia e Cola:</p>
              <p className="text-xs text-gray-700 break-all font-mono leading-relaxed">{qrCode}</p>
              <button
                onClick={copy}
                className="mt-2 w-full flex items-center justify-center gap-2 bg-gray-800 text-white py-2 rounded-lg text-sm font-medium"
              >
                {copied ? <CheckCheck className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                {copied ? 'Copiado!' : 'Copiar código'}
              </button>
            </div>
          )}
          <p className="text-xs text-gray-400 animate-pulse">⏳ Aguardando confirmação do pagamento...</p>
        </div>
      )}
    </div>
  );
}