import { Plus } from 'lucide-react';
import { formatPrice } from '../../lib/formatPrice';

export default function ProductCard({ id, name, description, price, imageUrl, onAdd }) {
  return (
    <div
      className="flex items-center justify-between bg-white rounded-2xl shadow-sm border border-gray-100 p-3 gap-3 cursor-pointer active:scale-95 transition-transform"
      onClick={onAdd}
    >
      <div className="flex-1 min-w-0">
        <h3 className="font-semibold text-gray-900 text-sm leading-tight">{name}</h3>
        {description && (
          <p className="text-xs text-gray-500 mt-0.5 line-clamp-2">{description}</p>
        )}
        <p className="text-sm font-bold text-amber-600 mt-1">{formatPrice(price)}</p>
      </div>
      <div className="relative flex-shrink-0">
        {imageUrl ? (
          <img src={imageUrl} alt={name} className="w-20 h-20 object-cover rounded-xl" />
        ) : (
          <div className="w-20 h-20 rounded-xl bg-amber-50 flex items-center justify-center text-3xl">🍗</div>
        )}
        <button
          onClick={(e) => { e.stopPropagation(); onAdd(); }}
          className="absolute -bottom-1 -right-1 bg-amber-500 text-white rounded-full w-7 h-7 flex items-center justify-center shadow-md"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}