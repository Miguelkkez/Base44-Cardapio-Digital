const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect } from 'react';
import { X, Plus, Minus, CheckCircle2 } from 'lucide-react';
import { formatPrice } from '../../lib/formatPrice';
import { useCart } from '../../lib/CartContext';
import { getProductGroups } from '../../lib/productGroups';

export default function ProductModal({ product, categoryName, onClose }) {
  const [quantity, setQuantity] = useState(1);
  const [notes, setNotes] = useState('');
  const [selections, setSelections] = useState({});
  const [errors, setErrors] = useState({});
  const { addItem } = useCart();

  const [pausedOptions, setPausedOptions] = useState([]);

  useEffect(() => {
    db.entities.PausedOption.list().then(setPausedOptions);
  }, []);

  const rawGroups = getProductGroups(product, categoryName);
  const groups = rawGroups.map(g => ({
    ...g,
    options: g.options.filter(o => !pausedOptions.some(p => p.group_id === g.id && p.option_name === o.name)),
  })).filter(g => g.options.length > 0);

  const getSelected = (groupId) => selections[groupId] || [];

  const toggleOption = (group, optionName) => {
    const current = getSelected(group.id);

    if (group.allowRepeat) {
      // Count occurrences
      const count = current.filter(n => n === optionName).length;
      const total = current.length;
      if (count > 0) {
        // Remove one occurrence
        const idx = current.indexOf(optionName);
        const next = [...current.slice(0, idx), ...current.slice(idx + 1)];
        setSelections(s => ({ ...s, [group.id]: next }));
      } else if (total < group.max) {
        setSelections(s => ({ ...s, [group.id]: [...current, optionName] }));
      }
    } else {
      const isSelected = current.includes(optionName);
      if (isSelected) {
        setSelections(s => ({ ...s, [group.id]: current.filter(n => n !== optionName) }));
      } else if (current.length < group.max) {
        setSelections(s => ({ ...s, [group.id]: [...current, optionName] }));
      }
    }

    setErrors(e => ({ ...e, [group.id]: false }));
  };

  const addOne = (group, optionName) => {
    const current = getSelected(group.id);
    if (current.length < group.max) {
      setSelections(s => ({ ...s, [group.id]: [...current, optionName] }));
      setErrors(e => ({ ...e, [group.id]: false }));
    }
  };

  const removeOne = (group, optionName) => {
    const current = getSelected(group.id);
    const idx = current.indexOf(optionName);
    if (idx >= 0) {
      const next = [...current.slice(0, idx), ...current.slice(idx + 1)];
      setSelections(s => ({ ...s, [group.id]: next }));
    }
  };

  const validate = () => {
    const newErrors = {};
    groups.forEach(g => {
      const count = getSelected(g.id).length;
      if (count < g.min) newErrors[g.id] = true;
    });
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const extraPrice = groups.reduce((sum, g) => {
    const opts = g.options.reduce((m, o) => ({ ...m, [o.name]: o.price }), {});
    return sum + getSelected(g.id).reduce((s, name) => s + (opts[name] || 0), 0);
  }, 0);

  const totalPrice = (product.price + extraPrice) * quantity;

  const buildDescription = () => {
    return groups
      .map(g => {
        const sel = getSelected(g.id);
        if (sel.length === 0) return null;
        return `${g.name}: ${sel.join(', ')}`;
      })
      .filter(Boolean)
      .join(' | ');
  };

  const handleAdd = () => {
    if (!validate()) return;
    addItem({
      productId: product.id,
      name: product.name,
      price: product.price + extraPrice,
      quantity,
      notes: [notes, buildDescription()].filter(Boolean).join(' | '),
      imageUrl: product.image_url,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50" onClick={onClose}>
      <div
        className="bg-white w-full max-w-md rounded-t-3xl flex flex-col max-h-[90vh]"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex justify-between items-start p-5 pb-3 border-b">
          <div className="flex-1 pr-3">
            <h2 className="text-lg font-bold text-gray-900">{product.name}</h2>
            {product.description && <p className="text-xs text-gray-500 mt-0.5 line-clamp-2">{product.description}</p>}
            <p className="text-amber-600 font-bold mt-1">{formatPrice(product.price)}</p>
          </div>
          <button onClick={onClose} className="p-1 text-gray-400 hover:text-gray-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable groups */}
        <div className="flex-1 overflow-auto px-5 py-4 space-y-5">
          {groups.map(group => {
            const selected = getSelected(group.id);
            const hasError = errors[group.id];
            return (
              <div key={group.id}>
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <p className="font-semibold text-gray-800 text-sm">{group.name}</p>
                    <p className="text-xs text-gray-400">
                      {group.min > 0 ? `Obrigatório · ` : ''}
                      {group.max === 1 ? 'Escolha 1' : `Escolha até ${group.max}`}
                      {group.allowRepeat ? ' (pode repetir)' : ''}
                    </p>
                  </div>
                  {group.min > 0 && (
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${hasError ? 'bg-red-100 text-red-600' : 'bg-amber-100 text-amber-700'}`}>
                      {hasError ? 'Obrigatório' : 'Obrigatório'}
                    </span>
                  )}
                </div>

                <div className="space-y-2">
                  {group.options.map(opt => {
                    const count = selected.filter(n => n === opt.name).length;
                    const isSelected = count > 0;
                    const atMax = selected.length >= group.max;

                    return (
                      <div key={opt.name} className={`flex items-center justify-between p-3 rounded-xl border transition-colors ${isSelected ? 'border-amber-400 bg-amber-50' : 'border-gray-100 bg-gray-50'}`}>
                        <div className="flex items-center gap-2">
                          {isSelected && <CheckCircle2 className="w-4 h-4 text-amber-500 flex-shrink-0" />}
                          <span className="text-sm text-gray-800">{opt.name}</span>
                          {opt.price > 0 && <span className="text-xs text-amber-600 font-medium">+{formatPrice(opt.price)}</span>}
                          {opt.price === 0 && <span className="text-xs text-gray-400">Grátis</span>}
                        </div>

                        {group.allowRepeat && group.max > 1 ? (
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => removeOne(group, opt.name)}
                              disabled={count === 0}
                              className="w-7 h-7 rounded-full border flex items-center justify-center text-gray-500 disabled:opacity-30"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="text-sm font-bold w-4 text-center">{count}</span>
                            <button
                              onClick={() => addOne(group, opt.name)}
                              disabled={atMax}
                              className="w-7 h-7 rounded-full bg-amber-500 text-white flex items-center justify-center disabled:opacity-30"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => toggleOption(group, opt.name)}
                            disabled={!isSelected && atMax}
                            className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors ${isSelected ? 'bg-amber-500 border-amber-500' : 'border-gray-300'} disabled:opacity-30`}
                          >
                            {isSelected && <div className="w-2 h-2 rounded-full bg-white" />}
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>

                {hasError && (
                  <p className="text-xs text-red-500 mt-1">Selecione pelo menos {group.min} opção(ões).</p>
                )}
              </div>
            );
          })}

          {/* Notes */}
          <div>
            <label className="text-xs font-medium text-gray-600">Observações (opcional)</label>
            <textarea
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="Ex: sem cebola, bem passado..."
              className="w-full mt-1 p-2 border rounded-xl text-sm resize-none h-16 focus:outline-none focus:ring-2 focus:ring-amber-400"
            />
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setQuantity(q => Math.max(1, q - 1))}
              className="w-8 h-8 rounded-full border flex items-center justify-center text-gray-600"
            >
              <Minus className="w-4 h-4" />
            </button>
            <span className="font-bold text-lg w-6 text-center">{quantity}</span>
            <button
              onClick={() => setQuantity(q => q + 1)}
              className="w-8 h-8 rounded-full bg-amber-500 text-white flex items-center justify-center"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
          <button
            onClick={handleAdd}
            className="flex-1 bg-amber-500 text-white py-2.5 rounded-xl font-semibold text-sm"
          >
            Adicionar · {formatPrice(totalPrice)}
          </button>
        </div>
      </div>
    </div>
  );
}