import { ShoppingBag } from 'lucide-react';
import { useCart } from '../../lib/CartContext';
import { formatPrice } from '../../lib/formatPrice';

export default function FloatingCart({ onClick }) {
  const { totalItems, totalPrice } = useCart();

  if (totalItems === 0) return null;

  return (
    <button
      onClick={onClick}
      className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-amber-500 text-white rounded-2xl px-5 py-3.5 flex items-center gap-3 shadow-xl z-40 w-[calc(100%-2rem)] max-w-sm"
    >
      <span className="bg-white text-amber-600 rounded-lg w-7 h-7 flex items-center justify-center font-bold text-sm">
        {totalItems}
      </span>
      <span className="flex-1 text-left font-semibold">Ver Sacola</span>
      <span className="font-bold">{formatPrice(totalPrice)}</span>
    </button>
  );
}