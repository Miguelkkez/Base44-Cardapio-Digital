const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from 'react';
import { ArrowLeft, Minus, Plus, Trash2, CheckCircle2 } from 'lucide-react';
import { useCart } from '../../lib/CartContext';

import PixPayment from './PixPayment';
import { Copy, CheckCheck, Loader2 } from 'lucide-react';
import { formatPrice } from '../../lib/formatPrice';

export default function CartSheet({ onClose, onOrderPlaced }) {
  const { items, updateQuantity, removeItem, totalPrice, clearCart } = useCart();
  const [step, setStep] = useState('cart');
  const [name, setName] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [placedOrderTotal, setPlacedOrderTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [orderId, setOrderId] = useState('');

  const handleSubmit = async () => {
    if (!name.trim() || !whatsapp.trim()) return;
    setLoading(true);
    const order = await db.entities.Order.create({
      customer_name: name.trim(),
      customer_whatsapp: whatsapp.trim(),
      total: totalPrice,
      status: 'novo',
    });
    await Promise.all(items.map(item =>
      db.entities.OrderItem.create({
        order_id: order.id,
        product_id: item.productId,
        product_name: item.name,
        quantity: item.quantity,
        unit_price: item.price,
        notes: item.notes || null,
      })
    ));
    setOrderId(order.id);
    setPlacedOrderTotal(totalPrice);
    localStorage.setItem('active_order_id', order.id);
    clearCart();
    setLoading(false);
    setStep('success');
    onOrderPlaced(order.id);
  };

  if (step === 'pix') {
    return (
      <div className="fixed inset-0 bg-white z-50 flex flex-col">
        <div className="flex items-center gap-3 p-4 border-b">
          <h2 className="font-bold text-lg">Pagar com PIX</h2>
        </div>
        <div className="flex-1 overflow-auto p-4">
          <PixPayment total={placedOrderTotal} onDone={onClose} />
        </div>
      </div>
    );
  }

  if (step === 'success') {
    return (
      <div className="fixed inset-0 bg-white z-50 flex flex-col items-center justify-center px-6 text-center gap-4">
        <CheckCircle2 className="w-16 h-16 text-green-500" />
        <h2 className="text-2xl font-bold text-gray-900">Pedido Confirmado!</h2>
        <p className="text-gray-500 text-sm">Seu pedido foi recebido! Como deseja pagar?</p>
        <button
          onClick={() => setStep('pix')}
          className="w-full bg-green-500 text-white py-3.5 rounded-xl font-semibold"
        >
          💸 Pagar com PIX agora
        </button>
        <button
          onClick={onClose}
          className="w-full border py-3.5 rounded-xl font-semibold text-gray-700"
        >
          Pagar na retirada
        </button>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-white z-50 flex flex-col">
      <div className="flex items-center gap-3 p-4 border-b">
        <button onClick={step === 'checkout' ? () => setStep('cart') : onClose}>
          <ArrowLeft className="w-5 h-5 text-gray-600" />
        </button>
        <h2 className="font-bold text-lg">{step === 'cart' ? 'Sua Sacola' : 'Finalizar Pedido'}</h2>
      </div>

      <div className="flex-1 overflow-auto p-4">
        {step === 'cart' ? (
          <>
            {items.length === 0 ? (
              <p className="text-center text-gray-400 mt-10">Sua sacola está vazia</p>
            ) : (
              <div className="space-y-3">
                {items.map(item => (
                  <div key={item.productId + item.notes} className="flex items-center gap-3">
                    <div className="flex-1">
                      <p className="font-medium text-sm text-gray-900">{item.name}</p>
                      {item.notes && <p className="text-xs text-gray-400">{item.notes}</p>}
                      <p className="text-amber-600 font-bold text-sm">{formatPrice(item.price)}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button onClick={() => updateQuantity(item.productId, item.quantity - 1)} className="w-7 h-7 rounded-full border flex items-center justify-center">
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="text-sm font-bold w-4 text-center">{item.quantity}</span>
                      <button onClick={() => updateQuantity(item.productId, item.quantity + 1)} className="w-7 h-7 rounded-full bg-amber-500 text-white flex items-center justify-center">
                        <Plus className="w-3 h-3" />
                      </button>
                      <button onClick={() => removeItem(item.productId)} className="ml-1 text-red-400">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        ) : (
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-700">Nome</label>
              <input value={name} onChange={e => setName(e.target.value)} className="w-full mt-1 border rounded-xl p-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400" placeholder="Seu nome" />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700">WhatsApp</label>
              <input value={whatsapp} onChange={e => setWhatsapp(e.target.value)} className="w-full mt-1 border rounded-xl p-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400" placeholder="(11) 99999-9999" />
            </div>
            <p className="text-xs text-gray-500 bg-amber-50 p-3 rounded-xl">💰 O pagamento será feito na retirada ou via PIX.</p>
            <div className="border-t pt-3">
              <p className="font-semibold text-sm text-gray-700 mb-2">Resumo do pedido</p>
              {items.map(item => (
                <div key={item.productId + item.notes} className="flex justify-between text-sm text-gray-600 mb-1">
                  <span>{item.quantity}x {item.name}</span>
                  <span>{formatPrice(item.price * item.quantity)}</span>
                </div>
              ))}
              <div className="flex justify-between font-bold mt-2 pt-2 border-t">
                <span>Total</span>
                <span className="text-amber-600">{formatPrice(totalPrice)}</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {step === 'cart' && items.length > 0 && (
        <div className="p-4 border-t">
          <div className="flex justify-between font-bold mb-3">
            <span>Total</span>
            <span className="text-amber-600">{formatPrice(totalPrice)}</span>
          </div>
          <button onClick={() => setStep('checkout')} className="w-full bg-amber-500 text-white py-3.5 rounded-xl font-semibold">
            Continuar
          </button>
        </div>
      )}

      {step === 'checkout' && (
        <div className="p-4 border-t">
          <button
            onClick={handleSubmit}
            disabled={loading || !name.trim() || !whatsapp.trim()}
            className="w-full bg-amber-500 text-white py-3.5 rounded-xl font-semibold disabled:opacity-50"
          >
            {loading ? 'Enviando...' : 'Confirmar Pedido'}
          </button>
        </div>
      )}
    </div>
  );
}