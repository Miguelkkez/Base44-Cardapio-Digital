import { useState } from 'react';

const ADMIN_PASSWORD = '87068055';

export default function AdminLogin({ onSuccess }) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      sessionStorage.setItem('admin_token', '1');
      onSuccess();
    } else {
      setError('Senha incorreta');
    }
  };

  return (
    <div className="min-h-screen bg-amber-50 flex items-center justify-center px-4">
      <div className="bg-white rounded-2xl shadow-lg p-8 w-full max-w-sm">
        <h1 className="text-2xl font-bold text-center text-gray-900 mb-1">🍗 El Pote</h1>
        <p className="text-center text-gray-500 text-sm mb-6">Painel Administrativo</p>
        <form onSubmit={handleSubmit}>
          <label className="text-sm font-medium text-gray-700">Senha</label>
          <input
            type="password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            className="w-full mt-1 border rounded-xl p-3 focus:outline-none focus:ring-2 focus:ring-amber-400"
            placeholder="••••••"
          />
          {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
          <button type="submit" className="w-full bg-amber-500 text-white py-3 rounded-xl font-semibold mt-4">
            Entrar
          </button>
        </form>
      </div>
    </div>
  );
}