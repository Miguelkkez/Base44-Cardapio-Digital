const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect } from 'react';

import { Plus, Pencil, Trash2, X, Check, PauseCircle, PlayCircle } from 'lucide-react';

const emptyForm = { name: '', active: true, sort_order: 0 };

export default function CategoriesManager() {
  const [categories, setCategories] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [editId, setEditId] = useState(null);
  const [showForm, setShowForm] = useState(false);

  const load = () => db.entities.Category.list().then(setCategories);

  useEffect(() => { load(); }, []);

  const save = async () => {
    const data = { ...form, sort_order: parseInt(form.sort_order) || 0 };
    if (editId) await db.entities.Category.update(editId, data);
    else await db.entities.Category.create(data);
    setForm(emptyForm); setEditId(null); setShowForm(false); load();
  };

  const del = async (id) => { await db.entities.Category.delete(id); load(); };

  const toggleActive = async (c) => {
    await db.entities.Category.update(c.id, { active: !c.active });
    if (c.active) {
      const products = await db.entities.Product.filter({ category_id: c.id });
      await Promise.all(products.map(p => db.entities.Product.update(p.id, { active: false })));
    }
    load();
  };
  const edit = (c) => { setForm({ ...c, sort_order: String(c.sort_order) }); setEditId(c.id); setShowForm(true); };

  return (
    <div className="p-3">
      <div className="flex justify-between items-center mb-3">
        <h3 className="font-bold text-gray-800">Categorias</h3>
        <button onClick={() => { setShowForm(true); setEditId(null); setForm(emptyForm); }} className="bg-amber-500 text-white rounded-lg px-3 py-1.5 text-xs flex items-center gap-1">
          <Plus className="w-3 h-3" /> Nova
        </button>
      </div>

      {showForm && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3 mb-3 space-y-2">
          <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Nome da categoria" className="w-full border rounded-lg p-2 text-sm focus:outline-none focus:ring-1 focus:ring-amber-400" />
          <input value={form.sort_order} onChange={e => setForm(f => ({ ...f, sort_order: e.target.value }))} placeholder="Ordem" type="number" className="w-full border rounded-lg p-2 text-sm focus:outline-none focus:ring-1 focus:ring-amber-400" />
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={form.active} onChange={e => setForm(f => ({ ...f, active: e.target.checked }))} />
            Ativa
          </label>
          <div className="flex gap-2">
            <button onClick={save} className="flex-1 bg-amber-500 text-white py-2 rounded-lg text-sm font-medium flex items-center justify-center gap-1">
              <Check className="w-4 h-4" /> Salvar
            </button>
            <button onClick={() => setShowForm(false)} className="px-3 py-2 border rounded-lg text-sm text-gray-600"><X className="w-4 h-4" /></button>
          </div>
        </div>
      )}

      <div className="space-y-2">
        {categories.map(c => (
          <div key={c.id} className="bg-white rounded-xl border p-3 flex items-center gap-3">
            <div className="flex-1">
              <p className="font-medium text-sm text-gray-900">{c.name}</p>
              {!c.active && <span className="text-xs text-gray-400">Inativa</span>}
            </div>
            <div className="flex gap-1">
              <button onClick={() => toggleActive(c)} className="p-1.5 rounded-lg hover:bg-gray-100" title={c.active ? 'Pausar categoria e seus itens' : 'Ativar'}>
                {c.active ? <PauseCircle className="w-3.5 h-3.5 text-amber-500" /> : <PlayCircle className="w-3.5 h-3.5 text-green-500" />}
              </button>
              <button onClick={() => edit(c)} className="p-1.5 rounded-lg hover:bg-gray-100"><Pencil className="w-3.5 h-3.5 text-gray-500" /></button>
              <button onClick={() => del(c.id)} className="p-1.5 rounded-lg hover:bg-red-50"><Trash2 className="w-3.5 h-3.5 text-red-400" /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}