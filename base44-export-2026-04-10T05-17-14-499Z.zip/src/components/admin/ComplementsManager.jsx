const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect } from 'react';

import { PauseCircle, PlayCircle } from 'lucide-react';

const ALL_OPTIONS = [
  { group_id: 'cortes', group_name: 'Cortes', options: ['Filé de sassami', 'Coxinha da asa', 'Filé de sobrecoxa'] },
  { group_id: 'temperos', group_name: 'Temperos', options: ['Pimenta do reino', 'Páprica defumada'] },
  { group_id: 'molhos', group_name: 'Molhos', options: ['Maionese temperada', 'Mostarda e mel', 'Rosé picante', 'Maionese de alho', 'Barbecue', 'Catchup'] },
  { group_id: 'bebidas', group_name: 'Bebidas Extras', options: ['Coca-Cola'] },
];

export default function ComplementsManager() {
  const [paused, setPaused] = useState([]);

  const load = async () => {
    const data = await db.entities.PausedOption.list();
    setPaused(data);
  };

  useEffect(() => { load(); }, []);

  const isPaused = (group_id, option_name) =>
    paused.some(p => p.group_id === group_id && p.option_name === option_name);

  const toggle = async (group_id, option_name) => {
    const existing = paused.find(p => p.group_id === group_id && p.option_name === option_name);
    if (existing) {
      await db.entities.PausedOption.delete(existing.id);
    } else {
      await db.entities.PausedOption.create({ group_id, option_name });
    }
    load();
  };

  return (
    <div className="p-3 space-y-4">
      <h3 className="font-bold text-gray-800">Complementos</h3>
      {ALL_OPTIONS.map(({ group_id, group_name, options }) => (
        <div key={group_id}>
          <p className="text-xs font-semibold text-gray-500 uppercase mb-2">{group_name}</p>
          <div className="space-y-1.5">
            {options.map(opt => {
              const paused_ = isPaused(group_id, opt);
              return (
                <div key={opt} className={`flex items-center justify-between p-2.5 rounded-xl border ${paused_ ? 'bg-gray-50 border-gray-200 opacity-60' : 'bg-white border-gray-100'}`}>
                  <span className={`text-sm ${paused_ ? 'line-through text-gray-400' : 'text-gray-800'}`}>{opt}</span>
                  <button onClick={() => toggle(group_id, opt)} className="p-1">
                    {paused_
                      ? <PlayCircle className="w-5 h-5 text-green-500" />
                      : <PauseCircle className="w-5 h-5 text-amber-500" />}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}