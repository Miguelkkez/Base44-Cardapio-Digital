const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect } from 'react';

import { formatPrice } from '../../lib/formatPrice';
import { Phone, Clock, ChevronRight, Printer } from 'lucide-react';

const STATUS_CONFIG = {
  novo: { label: '🔔 Novos', next: 'em_preparo', nextLabel: 'Preparar', color: 'bg-blue-100 text-blue-800' },
  em_preparo: { label: '👨🍳 Preparando', next: 'pronto', nextLabel: 'Pronto', color: 'bg-amber-100 text-amber-800' },
  pronto: { label: '✅ Prontos', next: 'finalizado', nextLabel: 'Confirmar Retirada', color: 'bg-green-100 text-green-800' },
};

const ORDER_TABS = ['novo', 'em_preparo', 'pronto'];

const formatTime = (d) => new Date(d).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

export default function OrdersPanel() {
  const [activeTab, setActiveTab] = useState('novo');
  const [orders, setOrders] = useState([]);
  const [orderItems, setOrderItems] = useState({});

  const loadOrders = async () => {
    const data = await db.entities.Order.list('-created_date', 100);
    setOrders(data.filter(o => o.status !== 'finalizado'));
    // Load items for each order
    const all = await db.entities.OrderItem.list('-created_date', 500);
    const grouped = {};
    all.forEach(item => {
      if (!grouped[item.order_id]) grouped[item.order_id] = [];
      grouped[item.order_id].push(item);
    });
    setOrderItems(grouped);
  };

  useEffect(() => {
    loadOrders();
    const interval = setInterval(loadOrders, 5000);
    return () => clearInterval(interval);
  }, []);

  const updateStatus = async (orderId, newStatus) => {
    await db.entities.Order.update(orderId, { status: newStatus });
    loadOrders();
  };

  const printOrder = (order) => {
    const items = (orderItems[order.id] || []);
    const w = window.open('', '_blank', 'width=400,height=600');
    if (!w) return;
    w.document.write(`<html><body style="font-family:monospace;padding:16px">
      <h2 style="text-align:center">El Pote Frango Frito</h2>
      <p><strong>${order.customer_name}</strong><br>📱 ${order.customer_whatsapp}<br>🕐 ${formatTime(order.created_date)}</p>
      <hr>
      ${items.map(i => `<p>${i.quantity}x ${i.product_name} — ${formatPrice(i.unit_price * i.quantity)}${i.notes ? `<br><small>↳ ${i.notes}</small>` : ''}</p>`).join('')}
      <hr>
      <p><strong>Total: ${formatPrice(order.total)}</strong></p>
      <p style="text-align:center;font-size:11px">Pagamento na retirada</p>
    </body></html>`);
    w.document.close();
    w.print();
  };

  const filteredOrders = orders.filter(o => o.status === activeTab);
  const counts = { novo: 0, em_preparo: 0, pronto: 0 };
  orders.forEach(o => { if (counts[o.status] !== undefined) counts[o.status]++; });

  return (
    <div className="flex flex-col h-full">
      <div className="flex border-b">
        {ORDER_TABS.map(status => (
          <button
            key={status}
            onClick={() => setActiveTab(status)}
            className={`flex-1 px-2 py-3 text-xs font-medium text-center border-b-2 transition-colors ${activeTab === status ? 'border-amber-500 text-amber-600' : 'border-transparent text-gray-500'}`}
          >
            {STATUS_CONFIG[status].label}
            {counts[status] > 0 && (
              <span className="ml-1 bg-red-500 text-white rounded-full text-xs px-1.5 py-0.5">{counts[status]}</span>
            )}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-auto p-3 space-y-3">
        {filteredOrders.length === 0 ? (
          <p className="text-center text-gray-400 text-sm mt-8">Nenhum pedido nesta categoria</p>
        ) : (
          filteredOrders.map(order => (
            <div key={order.id} className="bg-white rounded-2xl border p-3 shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <div>
                  <p className="font-bold text-gray-900 text-sm">{order.customer_name}</p>
                  <a href={`https://wa.me/55${order.customer_whatsapp.replace(/\D/g, '')}`} className="text-green-600 text-xs flex items-center gap-1">
                    <Phone className="w-3 h-3" />{order.customer_whatsapp}
                  </a>
                </div>
                <div className="flex items-center gap-1 text-gray-400 text-xs">
                  <button onClick={() => printOrder(order)} className="p-1.5 rounded-lg hover:bg-gray-100">
                    <Printer className="w-4 h-4" />
                  </button>
                  <Clock className="w-3 h-3" />{formatTime(order.created_date)}
                </div>
              </div>

              {(orderItems[order.id] || []).map(item => (
                <div key={item.id} className="flex justify-between text-xs text-gray-600 mb-0.5">
                  <span>{item.quantity}x {item.product_name}</span>
                  <span>{formatPrice(item.unit_price * item.quantity)}</span>
                </div>
              ))}

              <div className="flex items-center justify-between mt-2 pt-2 border-t">
                <span className="font-bold text-amber-600 text-sm">{formatPrice(order.total)}</span>
                {STATUS_CONFIG[activeTab]?.next && (
                  <button
                    onClick={() => updateStatus(order.id, STATUS_CONFIG[activeTab].next)}
                    className="bg-amber-500 text-white text-xs px-3 py-1.5 rounded-lg flex items-center gap-1"
                  >
                    {STATUS_CONFIG[activeTab].nextLabel} <ChevronRight className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}