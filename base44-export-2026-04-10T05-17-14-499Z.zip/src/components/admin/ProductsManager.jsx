const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect } from 'react';

import { formatPrice } from '../../lib/formatPrice';
import { Plus, Pencil, Trash2, X, Check, PauseCircle, PlayCircle } from 'lucide-react';

const emptyForm = { name: '', description: '', price: '', category_id: '', image_url: '', active: true, sort_order: 0 };

export default function ProductsManager() {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [editId, setEditId] = useState(null);
  const [showForm, setShowForm] = useState(false);

  const load = async () => {
    const [p, c] = await Promise.all([db.entities.Product.list(), db.entities.Category.list()]);
    setProducts(p);
    setCategories(c);
  };

  useEffect(() => { load(); }, []);

  const save = async () => {
    const data = { ...form, price: parseFloat(form.price) || 0, sort_order: parseInt(form.sort_order) || 0 };
    if (editId) {
      await db.entities.Product.update(editId, data);
    } else {
      await db.entities.Product.create(data);
    }
    setForm(emptyForm);
    setEditId(null);
    setShowForm(false);
    load();
  };

  const del = async (id) => {
    await db.entities.Product.delete(id);
    load();
  };

  const toggleActive = async (p) => {
    await db.entities.Product.update(p.id, { active: !p.active });
    load();
  };

  const edit = (p) => {
    setForm({ ...p, price: String(p.price), sort_order: String(p.sort_order) });
    setEditId(p.id);
    setShowForm(true);
  };

  return (
    <div className="p-3">
      <div className="flex justify-between items-center mb-3">
        <h3 className="font-bold text-gray-800">Produtos</h3>
        <button onClick={() => { setShowForm(true); setEditId(null); setForm(emptyForm); }} className="bg-amber-500 text-white rounded-lg px-3 py-1.5 text-xs flex items-center gap-1">
          <Plus className="w-3 h-3" /> Novo
        </button>
      </div>

      {showForm && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3 mb-3 space-y-2">
          <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Nome" className="w-full border rounded-lg p-2 text-sm focus:outline-none focus:ring-1 focus:ring-amber-400" />
          <input value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="Descrição" className="w-full border rounded-lg p-2 text-sm focus:outline-none focus:ring-1 focus:ring-amber-400" />
          <div className="flex gap-2">
            <input value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} placeholder="Preço" type="number" className="flex-1 border rounded-lg p-2 text-sm focus:outline-none focus:ring-1 focus:ring-amber-400" />
            <input value={form.sort_order} onChange={e => setForm(f => ({ ...f, sort_order: e.target.value }))} placeholder="Ordem" type="number" className="w-20 border rounded-lg p-2 text-sm focus:outline-none focus:ring-1 focus:ring-amber-400" />
          </div>
          <select value={form.category_id} onChange={e => setForm(f => ({ ...f, category_id: e.target.value }))} className="w-full border rounded-lg p-2 text-sm focus:outline-none focus:ring-1 focus:ring-amber-400">
            <option value="">Selecione a categoria</option>
            {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <input value={form.image_url} onChange={e => setForm(f => ({ ...f, image_url: e.target.value }))} placeholder="URL da imagem (opcional)" className="w-full border rounded-lg p-2 text-sm focus:outline-none focus:ring-1 focus:ring-amber-400" />
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={form.active} onChange={e => setForm(f => ({ ...f, active: e.target.checked }))} />
            Ativo
          </label>
          <div className="flex gap-2">
            <button onClick={save} className="flex-1 bg-amber-500 text-white py-2 rounded-lg text-sm font-medium flex items-center justify-center gap-1">
              <Check className="w-4 h-4" /> Salvar
            </button>
            <button onClick={() => setShowForm(false)} className="px-3 py-2 border rounded-lg text-sm text-gray-600">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      <div className="space-y-2">
        {products.map(p => (
          <div key={p.id} className="bg-white rounded-xl border p-3 flex items-center gap-3">
            {p.image_url ? (
              <img src={p.image_url} alt={p.name} className="w-10 h-10 rounded-lg object-cover flex-shrink-0" />
            ) : (
              <div className="w-10 h-10 rounded-lg bg-amber-50 flex items-center justify-center text-lg flex-shrink-0">🍗</div>
            )}
            <div className="flex-1 min-w-0">
              <p className="font-medium text-sm text-gray-900 truncate">{p.name}</p>
              <p className="text-amber-600 text-xs font-bold">{formatPrice(p.price)}</p>
              {!p.active && <span className="text-xs text-gray-400">Inativo</span>}
            </div>
            <div className="flex gap-1">
              <button onClick={() => toggleActive(p)} className="p-1.5 rounded-lg hover:bg-gray-100" title={p.active ? 'Pausar' : 'Ativar'}>
                {p.active ? <PauseCircle className="w-3.5 h-3.5 text-amber-500" /> : <PlayCircle className="w-3.5 h-3.5 text-green-500" />}
              </button>
              <button onClick={() => edit(p)} className="p-1.5 rounded-lg hover:bg-gray-100"><Pencil className="w-3.5 h-3.5 text-gray-500" /></button>
              <button onClick={() => del(p.id)} className="p-1.5 rounded-lg hover:bg-red-50"><Trash2 className="w-3.5 h-3.5 text-red-400" /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}