const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect } from 'react';

import { Star } from 'lucide-react';

export default function FeedbacksPanel() {
  const [feedbacks, setFeedbacks] = useState([]);

  useEffect(() => {
    db.entities.Feedback.list('-created_date', 50).then(setFeedbacks);
  }, []);

  const avg = feedbacks.length ? (feedbacks.reduce((s, f) => s + f.rating, 0) / feedbacks.length).toFixed(1) : null;

  return (
    <div className="p-3">
      {avg && (
        <div className="bg-amber-50 rounded-2xl p-4 mb-3 flex items-center gap-3">
          <div className="text-3xl font-bold text-amber-600">{avg}</div>
          <div>
            <div className="flex gap-0.5">
              {[1,2,3,4,5].map(s => <Star key={s} className={`w-4 h-4 ${s <= Math.round(avg) ? 'fill-amber-400 text-amber-400' : 'text-gray-300'}`} />)}
            </div>
            <p className="text-xs text-gray-500">{feedbacks.length} avaliações</p>
          </div>
        </div>
      )}

      <div className="space-y-2">
        {feedbacks.map(f => (
          <div key={f.id} className="bg-white rounded-xl border p-3">
            <div className="flex items-center justify-between mb-1">
              <p className="font-medium text-sm text-gray-900">{f.customer_name || 'Anônimo'}</p>
              <div className="flex gap-0.5">
                {[1,2,3,4,5].map(s => <Star key={s} className={`w-3 h-3 ${s <= f.rating ? 'fill-amber-400 text-amber-400' : 'text-gray-300'}`} />)}
              </div>
            </div>
            {f.comment && <p className="text-xs text-gray-500">{f.comment}</p>}
          </div>
        ))}
        {feedbacks.length === 0 && <p className="text-center text-gray-400 text-sm mt-8">Nenhum feedback ainda</p>}
      </div>
    </div>
  );
}