const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect } from 'react';

export default function StoreToggle() {
  const [isOpen, setIsOpen] = useState(true);
  const [settingsId, setSettingsId] = useState(null);

  useEffect(() => {
    db.entities.StoreSettings.list().then(data => {
      if (data[0]) { setIsOpen(data[0].is_open); setSettingsId(data[0].id); }
    });
  }, []);

  const toggle = async () => {
    const newVal = !isOpen;
    if (settingsId) {
      await db.entities.StoreSettings.update(settingsId, { is_open: newVal });
    } else {
      const s = await db.entities.StoreSettings.create({ is_open: newVal });
      setSettingsId(s.id);
    }
    setIsOpen(newVal);
  };

  return (
    <div className="flex items-center justify-between bg-white rounded-2xl border p-4 mx-3 mt-3">
      <div>
        <p className="font-semibold text-gray-900 text-sm">Status da Loja</p>
        <p className="text-xs text-gray-500">{isOpen ? 'Aceitando pedidos' : 'Loja fechada'}</p>
      </div>
      <button
        onClick={toggle}
        className={`relative w-12 h-6 rounded-full transition-colors ${isOpen ? 'bg-green-500' : 'bg-gray-300'}`}
      >
        <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-transform ${isOpen ? 'translate-x-7' : 'translate-x-1'}`} />
      </button>
    </div>
  );
}