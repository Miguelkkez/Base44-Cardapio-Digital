const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect } from 'react';

import { CartProvider } from '../lib/CartContext';
import ProductCard from '../components/customer/ProductCard';
import ProductModal from '../components/customer/ProductModal';
import FloatingCart from '../components/customer/FloatingCart';
import CartSheet from '../components/customer/CartSheet';
import OrderTracker from '../components/customer/OrderTracker';
import { ClipboardList } from 'lucide-react';

function CustomerPage() {
  const [activeCategory, setActiveCategory] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showCart, setShowCart] = useState(false);
  const [showOrder, setShowOrder] = useState(false);
  const [activeOrderId, setActiveOrderId] = useState(() => localStorage.getItem('active_order_id'));
  const [categories, setCategories] = useState([]);
  const [products, setProducts] = useState([]);
  const [storeOpen, setStoreOpen] = useState(true);

  useEffect(() => {
    db.entities.Category.filter({ active: true }).then(data => setCategories(data.sort((a, b) => a.sort_order - b.sort_order)));
    db.entities.Product.filter({ active: true }).then(data => setProducts(data.sort((a, b) => a.sort_order - b.sort_order)));
    db.entities.StoreSettings.list().then(data => {
      if (data[0]) setStoreOpen(data[0].is_open);
    });
  }, []);

  useEffect(() => {
    if (!activeOrderId) return;
    db.entities.Order.filter({ id: activeOrderId }).then(data => {
      if (!data[0] || data[0].status === 'finalizado') {
        localStorage.removeItem('active_order_id');
        setActiveOrderId(null);
        setShowOrder(false);
      }
    });
  }, [activeOrderId]);

  const handleOrderPlaced = (orderId) => {
    setActiveOrderId(orderId);
  };

  const handleCartClose = () => {
    setShowCart(false);
    if (localStorage.getItem('active_order_id')) {
      setShowOrder(true);
    }
  };

  const filtered = activeCategory ? products.filter(p => p.category_id === activeCategory) : products;
  const groupedProducts = activeCategory
    ? [{ category: categories.find(c => c.id === activeCategory), products: filtered }]
    : categories.map(cat => ({ category: cat, products: filtered.filter(p => p.category_id === cat.id) })).filter(g => g.products.length > 0);

  if (showOrder && activeOrderId) {
    return (
      <OrderTracker
        orderId={activeOrderId}
        onBack={() => { setShowOrder(false); setActiveOrderId(localStorage.getItem('active_order_id')); }}
      />
    );
  }

  if (showCart) {
    return <CartSheet onClose={handleCartClose} onOrderPlaced={handleOrderPlaced} />;
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-28">
      {/* Header */}
      <div className="bg-amber-500 text-white px-4 pt-10 pb-6">
        <div className="flex items-center justify-between">
          <div>
            <img src="https://media.db.com/images/public/69d596b6bc74bd205e433d2e/29117f372_Logotipo.png" alt="El Pote Frango Frito" className="h-16 object-contain" />
          </div>
          <div className="flex items-center gap-2">
            {activeOrderId && (
              <button
                onClick={() => setShowOrder(true)}
                className="bg-white/20 text-white rounded-xl px-3 py-2 text-xs flex items-center gap-1.5"
              >
                <ClipboardList className="w-4 h-4" />
                Meu Pedido
              </button>
            )}
            <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${storeOpen ? 'bg-green-500' : 'bg-red-500'}`}>
              {storeOpen ? 'Aberto' : 'Fechado'}
            </span>
          </div>
        </div>
      </div>

      {/* Category filter */}
      {categories.length > 0 && (
        <div className="flex gap-2 overflow-x-auto px-4 py-3 scrollbar-hide">
          <button
            onClick={() => setActiveCategory(null)}
            className={`flex-shrink-0 px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${!activeCategory ? 'bg-amber-500 text-white' : 'bg-white text-gray-600 border'}`}
          >
            Todos
          </button>
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`flex-shrink-0 px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${activeCategory === cat.id ? 'bg-amber-500 text-white' : 'bg-white text-gray-600 border'}`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      )}

      {!storeOpen && (
        <div className="mx-4 my-2 bg-red-50 border border-red-200 rounded-2xl p-3 text-center">
          <p className="text-red-600 font-medium text-sm">😔 Estamos fechados no momento</p>
        </div>
      )}

      {/* Products */}
      <div className="px-4 space-y-6">
        {groupedProducts.map(({ category, products: ps }) => (
          <div key={category?.id}>
            {category && !activeCategory && (
              <h2 className="font-bold text-gray-800 mb-2">{category.name}</h2>
            )}
            <div className="space-y-2">
              {ps.map(product => (
                <ProductCard
                  key={product.id}
                  {...product}
                  imageUrl={product.image_url}
                  onAdd={() => setSelectedProduct(product)}
                />
              ))}
            </div>
          </div>
        ))}
        {groupedProducts.length === 0 && (
          <div className="text-center py-16 text-gray-400">
            <p className="text-4xl mb-2">🍗</p>
            <p>Nenhum produto disponível</p>
          </div>
        )}
      </div>

      <FloatingCart onClick={() => setShowCart(true)} />

      {selectedProduct && (
        <ProductModal
          product={selectedProduct}
          categoryName={categories.find(c => c.id === selectedProduct.category_id)?.name}
          onClose={() => setSelectedProduct(null)}
        />
      )}
    </div>
  );
}

export default function Menu() {
  return (
    <CartProvider>
      <CustomerPage />
    </CartProvider>
  );
}