import { useState } from 'react';
import AdminLogin from '../components/admin/AdminLogin';
import OrdersPanel from '../components/admin/OrdersPanel';
import ProductsManager from '../components/admin/ProductsManager';
import CategoriesManager from '../components/admin/CategoriesManager';
import StoreToggle from '../components/admin/StoreToggle';
import FeedbacksPanel from '../components/admin/FeedbacksPanel';
import ComplementsManager from '../components/admin/ComplementsManager';
import { ShoppingBag, Settings, MessageCircle } from 'lucide-react';

function AdminDashboard() {
  const [section, setSection] = useState('pedidos');
  const [configTab, setConfigTab] = useState('produtos');

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col max-w-md mx-auto">
      {/* Header */}
      <div className="bg-amber-500 text-white px-4 py-3 flex items-center justify-between">
        <div>
          <h1 className="font-bold text-lg">🍗 El Pote Admin</h1>
        </div>
        <button
          onClick={() => { sessionStorage.removeItem('admin_token'); window.location.reload(); }}
          className="text-amber-100 text-xs"
        >
          Sair
        </button>
      </div>

      {/* Section tabs */}
      <div className="flex border-b bg-white">
        {[
          { key: 'pedidos', label: 'Pedidos', Icon: ShoppingBag },
          { key: 'configuracoes', label: 'Config', Icon: Settings },
          { key: 'feedbacks', label: 'Feedbacks', Icon: MessageCircle },
        ].map(({ key, label, Icon }) => (
          <button
            key={key}
            onClick={() => setSection(key)}
            className={`flex-1 flex items-center justify-center gap-1.5 px-2 py-3 text-xs font-medium border-b-2 transition-colors ${section === key ? 'border-amber-500 text-amber-600' : 'border-transparent text-gray-500'}`}
          >
            <Icon className="w-4 h-4" />{label}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-auto">
        {section === 'pedidos' && <OrdersPanel />}

        {section === 'configuracoes' && (
          <div>
            <StoreToggle />
            <div className="flex gap-2 px-3 mt-3">
              {['produtos', 'categorias', 'complementos'].map(t => (
              <button
                key={t}
                onClick={() => setConfigTab(t)}
                className={`flex-1 py-2 rounded-xl text-sm font-medium transition-colors ${configTab === t ? 'bg-amber-500 text-white' : 'bg-white border text-gray-600'}`}
              >
                {t === 'produtos' ? 'Produtos' : t === 'categorias' ? 'Categorias' : 'Complementos'}
              </button>
            ))}
            </div>
            {configTab === 'produtos' ? <ProductsManager /> : configTab === 'categorias' ? <CategoriesManager /> : <ComplementsManager />}
          </div>
        )}

        {section === 'feedbacks' && <FeedbacksPanel />}
      </div>
    </div>
  );
}

export default function Admin() {
  const [authenticated, setAuthenticated] = useState(() => !!sessionStorage.getItem('admin_token'));

  if (!authenticated) return <AdminLogin onSuccess={() => setAuthenticated(true)} />;

  return <AdminDashboard />;
}